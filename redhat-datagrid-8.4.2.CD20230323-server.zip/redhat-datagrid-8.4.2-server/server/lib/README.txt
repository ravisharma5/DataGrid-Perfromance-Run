Place any custom jars you wish to add to the server classpath in this directory.
